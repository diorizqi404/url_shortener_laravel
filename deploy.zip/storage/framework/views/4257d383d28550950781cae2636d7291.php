

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                    <div class="card-body">
                        

                        <?php echo e(__('You are logged in!')); ?>

                    </div>
                </div>
                <?php if(session('success')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
                <form action="<?php echo e(route('generate-url')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="text" name="original_url" class="form-control mt-3" placeholder="Enter URL">
                    <input type="text" name="shortened_url" class="form-control mt-3" placeholder="Enter Custom URL" id="shortened_url">
                    <button type="button" name="generate" class="btn btn-primary mt-3" onclick="generateRandomURL()">generate random</button>
                    <button type="submit" name="submit" class="btn btn-primary mt-3">submit</button>
                </form>
                <br>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Original URL</th>
                            <th>Short URL</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $urls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($u->original_url); ?></td>
                                <td><a href="<?php echo e(route('shortened-url', $u->shortened_url)); ?>"
                                        target="_blank"><?php echo e(route('shortened-url', $u->shortened_url)); ?></a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
            </div>
        </div>
    </div>
		<script>
			let generateRandomURL = () => {
				let chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
				let shortUrl = "";
				for(let x = 0; x <= 6; x++){
					shortUrl += chars[Math.floor(Math.random() * chars.length)];
				}
				document.getElementById('shortened_url').value = shortUrl;
			}
		</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rizqi\Documents\coding\Laravel-Projects\url_shortener\resources\views/home.blade.php ENDPATH**/ ?>